import UIKit

enum ordinarySandwich {
   case wheat
   case mayonaisse
   case meat
   case cheddar
   case veggies
   case recipe
   }

var buildingBurger = ordinarySandwich.recipe

switch buildingBurger{

case .recipe:
    print("Lay out your bread.", "Spread your mayo on the bread.", "Add the turkey or chicken next."," Add the cheese and melt, if you desire.", " Lastly, apply any vegetable that you want. Then, enjoy!")
case .wheat:
    print("Lay out your bread.")
case .mayonaisse:
    print("Spread your mayo on the bread.")
case .meat:
    print(" Add the turkey or chicken next.")
case .cheddar:
    print(" Add the cheese and melt, if you desire.")
case .veggies:
    print(" Lastly, apply any vegetable that you want. Then, enjoy!")
}

